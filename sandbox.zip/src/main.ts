import { createApp } from "vue";
import "./style.css";
import TaskList "./componets/TaskList.vue";

const app = createApp({});
app.componets("TaskList", TaskList);

createApp(App).mount("#app");
